#from  skimage
import glob
import os
import cv2
import  tensorflow as tf
from tensorflow.keras import layers, optimizers, datasets, Sequential
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# 数据集的地址  改为你自己的
path = './carplate1.6/train/chars2/'

# 缩放图片大小为100*100
w = 100
h = 100
c = 3

#2.read images
def read_img(path):
    # 定义函数read_img，用于读取图像数据，并且对图像进行resize格式统一处理
    cate=[path+x for x in os.listdir(path) if os.path.isdir(path+x)]
    # 创建层级列表cate，用于对数据存放目录下面的数据文件夹进行遍历，os.path.isdir用于判断文件是否是目录，然后对是目录文件的文件进行遍历
    imgs=[]
    # 创建保存图像的空列表
    labels=[]
    # 创建用于保存图像标签的空列表
    for idx,folder in enumerate(cate):
        # enumerate函数用于将一个可遍历的数据对象组合为一个索引序列，同时列出数据和下标,一般用在for循环当中
        for im in glob.glob(folder+'/*.jpg'):
            # 利用glob.glob函数搜索每个层级文件下面符合特定格式“/*.jpg”进行遍历
            #print('reading the images:%s'%(im))
            # 遍历图像的同时，打印每张图片的“路径+名称”信息
            img=cv2.imread(im)
            # 利用io.imread函数读取每一张被遍历的图像并将其赋值给img
            img=cv2.resize(img,(w,h))
            # 利用transform.resize函数对每张img图像进行大小缩放，统一处理为大小为w*h(即100*100)的图像
            imgs.append(img)
            # 将每张经过处理的图像数据保存在之前创建的imgs空列表当中
            labels.append(idx)
            # 将每张经过处理的图像的标签数据保存在之前创建的labels列表当中
    return np.asarray(imgs,np.float32),np.asarray(labels,np.int32)
    # 利用np.asarray函数对生成的imgs和labels列表数据进行转化，之后转化成数组数据（imgs转成浮点数型，labels转成整数型）
data,label=read_img(path)
# 将read_img函数处理之后的数据定义为样本数据data和标签数据label
print("shape of data:",data.shape)
# 查看样本数据的大小
print("shape of label:",label.shape)
# 查看标签数据的大小
# 保证生成的随机数具有可预测性,即相同的种子（seed值）所产生的随机数是相同的
seed = 785
np.random.seed(seed)

#切分数据集
(x_train, x_val, y_train, y_val) = train_test_split(data, label, test_size=0.20, random_state=seed)
x_train = x_train / 255
x_val = x_val / 255

#创建图像标签列表
flower_dict = {0:'0',1:'1',2:'2',3:'3',4:'4',5:'5',6:'6',7:'7',8:'8',9:'9',
            10:'A',11:'B',12:'C',13:'D',14:'E',15:'F',16:'G',17:'H',18:'J',19:'K',20:'L',21:'M',22:'N',23:'P',24:'Q'
                  ,25:'R',26:'S',27:'T',28:'U',29:'V',30:'W',31:'X',32:'Y',33:'Z'}

# 创建模型。模型包括3个卷积层和三个RELU激活函数，两个池化层
model = Sequential([
    # 调用layer.Con2D()创建了一个卷积层。32表示kernel的数量。padding=“same”表示填充输入以使输出具有与原始输入相同的长度，使用RELU函数
    layers.Conv2D(32, kernel_size=[5, 5], padding="same", activation=tf.nn.relu),
    # 调用layers.MaxPool2D()创建最大池化层，步长为2，padding=“same”表示填充输入以使输出具有与原始输入相同的长度。
    layers.MaxPool2D(pool_size=[2, 2], strides=2, padding='same'),
    # 利用dropout随机丢弃25%的神经元
    layers.Dropout(0.25),

    # 继续添加两个卷积层和一个最大池化层
    layers.Conv2D(64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu),
    layers.Conv2D(64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu),
    layers.MaxPool2D(pool_size=[2, 2], strides=2, padding='same'),
    layers.Dropout(0.25),

    # 继续添加两个卷积层和一个最大池化层
    layers.Conv2D(128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu),
    layers.MaxPool2D(pool_size=[2, 2], strides=2, padding='same'),
    # 利用dropout随机丢弃25%的神经元
    layers.Dropout(0.25),

    # Flatten层用来将输入“压平”，即把多维的输入一维化
    layers.Flatten(),
    # 调用layers.Dense()创建全连接层
    layers.Dense(512, activation=tf.nn.relu),
    layers.Dense(256, activation=tf.nn.relu),
    # 添加全连接层，最后输出每个分类（5）的数值
    layers.Dense(5, activation='softmax')
])

#使用Adam优化器，优化模型参数。lr(learning rate, 学习率)
opt = optimizers.Adam(lr=0.0001)
#编译模型以供训练。metrics=['accuracy']即评估模型在训练和测试时的性能的指标。
model.compile(optimizer=opt,
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

#训练模型，决定训练集和验证集，batch size：进行梯度下降时每个batch包含的样本数。
#verbose：日志显示，0为不在标准输出流输出日志信息，1为输出进度条记录，2为每个epoch输出一行记录
model.fit(x_train, y_train, epochs=20, validation_data=(x_val, y_val),batch_size=200, verbose=2)
#输出模型的结构和参数量
model.summary()

# 测试图像的地址 （改为自己的）
path_test = './words/'

imgs=[]
# 创建保存图像的空列表
for im in glob.glob(path_test+'/*.jpg'):
    # 利用glob.glob函数搜索每个层级文件下面符合特定格式“/*.jpg”进行遍历
    #print('reading the images:%s'%(im))
    # 遍历图像的同时，打印每张图片的“路径+名称”信息
    img=cv2.imread(im)
    # 利用io.imread函数读取每一张被遍历的图像并将其赋值给img
    img=cv2.resize(img,(w,h))
    # 利用cv2.resize函数对每张img图像进行大小缩放，统一处理为大小为w*h(即100*100)的图像
    imgs.append(img)
    # 将每张经过处理的图像数据保存在之前创建的imgs空列表当中
imgs = np.asarray(imgs,np.float32)

print("shape of data:",imgs.shape)

#将图像导入模型进行预测
prediction = model.predict_classes(imgs)
#绘制预测图像
for i in range(np.size(prediction)):
    #打印每张图像的预测结果
    print("第",i+1,"张预测:"+flower_dict[prediction[i]])
    img = plt.imread(path_test+"test1_"+str(i+1)+".jpg")
    plt.imshow(img)
    plt.show()

#保存模型
model.save('./Model/model.h5')

